#pragma once
#include "Common.h"

// 1�ܰ�: �⺻ ���� Ŭ���� (�ٸ� Ŭ���� ���� �ּ�ȭ)
class Session : public boost::enable_shared_from_this<Session> {
public:
    Session(boost::asio::io_context& io_context)
        : _socket(io_context), _strand(boost::asio::make_strand(io_context)),
        _user_id(0), _current_room_id(0), _room_manager(nullptr) {
    }

    tcp::socket& socket() { return _socket; }

    void set_room_manager(class RoomManager* rm) { _room_manager = rm; }

    void start() {
        _user_id = generate_user_id();
        std::cout << "Session started for user: " << _user_id << std::endl;
        read_header();
    }

    void send_message(const Message& msg) {
        boost::asio::post(_strand,
            boost::bind(&Session::do_send_message, shared_from_this(), msg));
    }

    uint32_t get_user_id() const { return _user_id; }
    uint32_t get_current_room_id() const { return _current_room_id; }
    void set_current_room_id(uint32_t room_id) { _current_room_id = room_id; }

    // ������ ���߿� ���� (RoomManager�� ���ǵ� ��)
    void handle_message();
    void leave_current_room();

private:
    // --- Protobuf�� �߰� ��� ---
    enum { HEADER_LENGTH = 4 }; // uint32_t�� �޽��� ���� ǥ��
    char _header_buf[HEADER_LENGTH];
    std::vector<char> _body_buf;

    void read_header() {
        std::cout << "Session Head" << std::endl;
        // 1. ���� 4����Ʈ ���� ����� ����
        boost::asio::async_read(_socket,
            boost::asio::buffer(_header_buf, HEADER_LENGTH),
            boost::asio::bind_executor(_strand,
                boost::bind(&Session::handle_read_header, shared_from_this(),
                    boost::asio::placeholders::error)));
    }

    void handle_read_header(const boost::system::error_code& error) {
        std::cout << "Sesion Handle Head" << std::endl;
        if (!error) {
            // 2. ������� �޽��� ���� ����
            uint32_t body_length = 0;
            std::memcpy(&body_length, _header_buf, HEADER_LENGTH);
            // ��Ʈ��ũ ����Ʈ ������� ntohl ��� �ʿ�
            // body_length = ntohl(body_length);

            _body_buf.resize(body_length);
            // 3. ����(body) �б�
            boost::asio::async_read(_socket,
                boost::asio::buffer(_body_buf.data(), body_length),
                boost::asio::bind_executor(_strand,
                    boost::bind(&Session::handle_read_body, shared_from_this(),
                        boost::asio::placeholders::error)));
        }
        else {
            handle_disconnect();
        }
    }

    void handle_read_body(const boost::system::error_code& error) {
        std::cout << "Session Handle Body" << std::endl;
        if (!error) {
            // 4. _body_buf�� protobuf �޽��� �����Ͱ� �������
            // ���� protobuf �޽��� �Ľ� �� ó�� ����:
            MessageHeader header;
            /*
            if (type.ParseFromArray(_body_buf.data(), static_cast<int>(_body_buf.size()))) {
                handle_message(type);
            } else {
                std::cerr << "Failed to parse protobuf message" << std::endl;
            }
            */

            // ���� �޽��� ���� ��� 
            read_header();
        }
        else {
            handle_disconnect();
        }
    }

    void do_send_message(const Message& msg) {
        bool write_in_progress = !_write_msgs.empty();
        _write_msgs.push_back(msg);
        if (!write_in_progress) {
            write();
        }
    }

    void write() {
        boost::asio::async_write(_socket,
            boost::asio::buffer(&_write_msgs.front(), sizeof(Message)),
            boost::asio::bind_executor(_strand,
                boost::bind(&Session::handle_write, shared_from_this(),
                    boost::asio::placeholders::error)));
    }

    void handle_write(const boost::system::error_code& error) {
        if (!error) {
            _write_msgs.pop_front();
            if (!_write_msgs.empty()) {
                write();
            }
        }
        else {
            handle_disconnect();
        }
    }

    void handle_disconnect() {
        std::cout << "User " << _user_id << " disconnected" << std::endl;
        if (_current_room_id > 0) {
            leave_current_room();
        }
        _socket.close();
    }

    uint32_t generate_user_id() {
        static uint32_t id_counter = 1000;
        return ++id_counter;
    }

    tcp::socket _socket;
    class RoomManager* _room_manager;  // �����ͷ� ����
    boost::asio::strand<boost::asio::io_context::executor_type> _strand;
    Message _read_msg;
    std::deque<Message> _write_msgs;
    uint32_t _user_id;
    uint32_t _current_room_id;
};