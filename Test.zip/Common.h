#pragma once
#include <boost/asio.hpp>
#include <boost/bind/bind.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/make_shared.hpp>
#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <memory>
#include <functional>
#include <cstring>
#include <deque>

#include <google/protobuf/message.h>

#include "../proto/ProtocolPacket.pb.h"


// �޽��� Ÿ�� ����
enum MessageType {
    MSG_CREATE_ROOM = 0,
    MSG_JOIN_ROOM = 1,
    MSG_LEAVE_ROOM = 2,
    MSG_CHAT = 3,
    MSG_ROOM_LIST = 4,
    MSG_USER_LIST = 5
};

// �޽��� ����ü
struct Message {
    uint32_t type;
    uint32_t room_id;
    uint32_t user_id;
    uint32_t data_length;
    char data[512];

    Message() : type(0), room_id(0), user_id(0), data_length(0) {
        memset(data, 0, sizeof(data));
    }
};


struct MessageHeader {
    google::protobuf::uint32 size;
    protobuf::Protocol protocol;
    uint32_t type;
};

const int MessageHeaderSize = sizeof(MessageHeader);

class Session;
class Room;
class RoomManager;

// typedef ����
typedef boost::shared_ptr<Session> SessionPtr;
typedef boost::shared_ptr<Room> RoomPtr;

using boost::asio::ip::tcp;