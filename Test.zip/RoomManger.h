#pragma once

#include "Common.h"
#include "Room.h"

// 3�ܰ�: RoomManager Ŭ���� ����
class RoomManager {
public:
    RoomManager() {
        // �⺻ ��� ����
        create_room(1, "General");
        create_room(2, "Gaming");
        create_room(3, "Development");
    }

    RoomPtr get_room(uint32_t room_id) {
        auto it = _rooms.find(room_id);
        return (it != _rooms.end()) ? it->second : RoomPtr();
    }

    RoomPtr create_room(uint32_t room_id, const std::string& name) {
        auto room = boost::make_shared<Room>(room_id, name);
        _rooms[room_id] = room;
        std::cout << "Room created: " << room_id << " - " << name << std::endl;
        return room;
    }

    void handle_message(SessionPtr session, const Message& msg) {
        std::cout << "RoomManager Handle" << std::endl;
        switch (msg.type) {
        case MSG_CREATE_ROOM:
            // �� ������ ������ ������ �ʿ��ϹǷ� ����
            break;
        case MSG_JOIN_ROOM:
            handle_join_room(session, msg);
            break;
        case MSG_LEAVE_ROOM:
            handle_leave_room(session, msg);
            break;
        case MSG_CHAT:
            handle_chat_message(session, msg);
            break;
        case MSG_ROOM_LIST:
            handle_room_list_request(session, msg);
            break;
        case MSG_USER_LIST:
            handle_user_list_request(session, msg);
            break;
        default:
            std::cout << "Unknown message type: " << msg.type << std::endl;
        }
    }

    std::map<uint32_t, RoomPtr> get_all_rooms() const {
        return _rooms;
    }

private:
    void handle_join_room(SessionPtr session, const Message& msg) {
        auto room = get_room(msg.room_id);
        if (room) {
            // ���� �뿡�� ������
            if (session->get_current_room_id() > 0) {
                auto current_room = get_room(session->get_current_room_id());
                if (current_room) {
                    current_room->leave(session);
                }
            }

            // �� �뿡 ����
            room->join(session);

            // ���� Ȯ�� �޽��� ����
            Message response;
            response.type = MSG_JOIN_ROOM;
            response.room_id = msg.room_id;
            response.user_id = session->get_user_id();
            std::string success_msg = "Successfully joined room " + room->get_name();
            response.data_length = success_msg.length();
            strcpy_s(response.data, success_msg.c_str());
            session->send_message(response);
        }
    }

    void handle_leave_room(SessionPtr session, const Message& msg) {
        auto room = get_room(session->get_current_room_id());
        if (room) {
            room->leave(session);

            Message response;
            response.type = MSG_LEAVE_ROOM;
            response.room_id = msg.room_id;
            response.user_id = session->get_user_id();
            std::string leave_msg = "Left room " + room->get_name();
            response.data_length = leave_msg.length();
            strcpy_s(response.data, leave_msg.c_str());
            session->send_message(response);
        }
    }

    void handle_chat_message(SessionPtr session, const Message& msg) {
        auto room = get_room(session->get_current_room_id());
        if (room) {
            Message broadcast_msg = msg;
            broadcast_msg.user_id = session->get_user_id();
            room->broadcast(broadcast_msg);
            std::cout << "Chat in room " << room->get_id() << " from user "
                << session->get_user_id() << ": " << msg.data << std::endl;
        }
    }

    void handle_room_list_request(SessionPtr session, const Message& msg) {
        Message response;
        response.type = MSG_ROOM_LIST;
        response.user_id = session->get_user_id();

        std::string room_list = "Available rooms:\n";
        auto rooms = get_all_rooms();
        for (const auto& pair : rooms) {
            auto room = pair.second;
            room_list += std::to_string(room->get_id()) + ": " + room->get_name()
                + " (" + std::to_string(room->get_member_count()) + " users)\n";
        }

        response.data_length = room_list.length();
        strcpy_s(response.data, room_list.c_str());
        session->send_message(response);
    }

    void handle_user_list_request(SessionPtr session, const Message& msg) {
        auto room = get_room(session->get_current_room_id());
        if (room) {
            Message response;
            response.type = MSG_USER_LIST;
            response.room_id = room->get_id();
            response.user_id = session->get_user_id();

            std::string user_list = "Users in room " + room->get_name() + ":\n";
            auto member_ids = room->get_member_ids();
            for (uint32_t id : member_ids) {
                user_list += "User " + std::to_string(id) + "\n";
            }

            response.data_length = user_list.length();
            strcpy_s(response.data, user_list.c_str());
            session->send_message(response);
        }
    }

    std::map<uint32_t, RoomPtr> _rooms;
};