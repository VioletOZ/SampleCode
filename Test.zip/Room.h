#pragma once
#include "Common.h"
#include "Session.h"

// 2�ܰ�: Room Ŭ���� ����
class Room {
public:
    Room(uint32_t id, const std::string& name) : _id(id), _name(name) {}

    void join(SessionPtr session) {
        _members.insert(session);
        session->set_current_room_id(_id);

        // ���� �˸� �޽��� ��ε�ĳ��Ʈ
        Message msg;
        msg.type = MSG_CHAT;
        msg.room_id = _id;
        msg.user_id = 0; // �ý��� �޽���
        std::string join_msg = "User " + std::to_string(session->get_user_id()) + " joined the room";
        msg.data_length = join_msg.length();
        strcpy_s(msg.data, join_msg.c_str());

        broadcast(msg);
        std::cout << "User " << session->get_user_id() << " joined room " << _id << std::endl;
    }

    void leave(SessionPtr session) {
        _members.erase(session);
        session->set_current_room_id(0);

        // ���� �˸� �޽��� ��ε�ĳ��Ʈ
        Message msg;
        msg.type = MSG_CHAT;
        msg.room_id = _id;
        msg.user_id = 0; // �ý��� �޽���
        std::string leave_msg = "User " + std::to_string(session->get_user_id()) + " left the room";
        msg.data_length = leave_msg.length();
        strcpy_s(msg.data, leave_msg.c_str());

        broadcast(msg);
        std::cout << "User " << session->get_user_id() << " left room " << _id << std::endl;
    }

    void broadcast(const Message& msg) {
        for (auto session : _members) {
            session->send_message(msg);
        }
    }

    uint32_t get_id() const { return _id; }
    const std::string& get_name() const { return _name; }
    size_t get_member_count() const { return _members.size(); }

    std::vector<uint32_t> get_member_ids() const {
        std::vector<uint32_t> ids;
        for (auto session : _members) {
            ids.push_back(session->get_user_id());
        }
        return ids;
    }

private:
    uint32_t _id;
    std::string _name;
    std::set<SessionPtr> _members;
};