﻿#define _CRT_SECURE_NO_WARNINGS

#include "Common.h"
#include "RoomManger.h"


void PrintProtobuf(google::protobuf::Message& msg) {
    std::string str;
    str = msg.DebugString();
    std::cout << str << std::endl;
}


// 4단계: 지연된 Session 메서드 구현
void Session::handle_message() {
    if (_room_manager) {
        std::cout << "Session Handle" << std::endl;
        _room_manager->handle_message(shared_from_this(), _read_msg);
    }
}

void Session::leave_current_room() {
    if (_room_manager && _current_room_id > 0) {
        auto room = _room_manager->get_room(_current_room_id);
        if (room) {
            room->leave(shared_from_this());
        }
    }
}

// 서버 클래스
class RoomServer {
public:
    RoomServer(boost::asio::io_context& io_context, short port)
        : _io_context(io_context), _acceptor(io_context, tcp::endpoint(tcp::v4(), port)) {
        start_accept();
    }

private:
    void start_accept() {
        SessionPtr new_session = boost::make_shared<Session>(_io_context);
        new_session->set_room_manager(&_room_manager);  // 매니저 설정

        _acceptor.async_accept(new_session->socket(),
            boost::bind(&RoomServer::handle_accept, this, new_session,
                boost::asio::placeholders::error));
    }

    void handle_accept(SessionPtr session, const boost::system::error_code& error) {
        if (!error) {
            session->start();
        }
        start_accept();
    }

    boost::asio::io_context& _io_context;
    tcp::acceptor _acceptor;
    RoomManager _room_manager;
};

// 메인 함수
int main() {
    try {
        boost::asio::io_context io_context;

        RoomServer server(io_context, 12345);
        std::cout << "Room Server started on port 12345" << std::endl;

        io_context.run();
    }
    catch (std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }

    return 0;
}