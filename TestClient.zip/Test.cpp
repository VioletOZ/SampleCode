#include <iostream>
#include <boost/asio.hpp>
#include <boost/bind/bind.hpp>

#include "Common.h"

using boost::asio::ip::tcp;

class Client : public std::enable_shared_from_this<Client> {
public:
    Client(boost::asio::io_context& io_context, const tcp::resolver::results_type& endpoints)
        : _io_context(io_context),
        _strand(boost::asio::make_strand(io_context)),
        _socket(io_context)
    {
        boost::asio::async_connect(_socket, endpoints,
                boost::bind(&Client::HandleConnect, this, boost::asio::placeholders::error));
    }

private:
    void HandleConnect(const boost::system::error_code& error) {
        if (!error) {
            std::cout << "Connected to server." << std::endl;

            ChatMessage chat_message;
            chat_message.set_sender("Client");
            chat_message.set_message("Hello, Protobuf!");

            std::string serialized_data;
            chat_message.SerializeToString(&serialized_data);

            uint32_t payload_size = htonl(static_cast<uint32_t>(serialized_data.size()));
            _buffer_to_send.resize(4 + serialized_data.size());
            std::memcpy(_buffer_to_send.data(), &payload_size, 4);
            std::memcpy(_buffer_to_send.data() + 4, serialized_data.data(), serialized_data.size());

            boost::asio::async_write(_socket,
                boost::asio::buffer(_buffer_to_send),
                boost::asio::bind_executor(_strand,
                    boost::bind(&Client::HandleWrite, shared_from_this(), boost::asio::placeholders::error)));
        }
        else {
            std::cerr << "Connect error: " << error.message() << std::endl;
        }
    }


    void HandleWrite(const boost::system::error_code& error) {
        if (!error) {
            std::cout << "Message sent successfully." << std::endl;

            boost::asio::async_write(_socket,
                boost::asio::buffer(_buffer_to_send),
                boost::asio::bind_executor(_strand,
                    boost::bind(&Client::HandleWrite, shared_from_this(), boost::asio::placeholders::error)));
        }
        else {
            std::cerr << "Write error: " << error.message() << std::endl;

            HandleDisconnect();
        }

    }

    void HandleDisconnect() {
        std::cout << "Disconnected from server." << std::endl;
        _socket.close();
    }

    boost::asio::io_context& _io_context;
    boost::asio::strand<boost::asio::io_context::executor_type> _strand;
    tcp::socket _socket;
    std::vector<char> _buffer_to_send;
};

int main() {
    try {
        boost::asio::io_context io_context;
        tcp::resolver resolver(io_context);
        auto endpoints = resolver.resolve("127.0.0.1", "12345");
        auto client = std::make_shared<Client>(io_context, endpoints);
        io_context.run();
    }
    catch (std::exception& e) {
        std::cerr << "Exception: " << e.what() << std::endl;
    }
    return 0;
}